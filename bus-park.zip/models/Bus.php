<?php
/**
 * Created by PhpStorm.
 * User: alexandr
 * Date: 23.06.17
 * Time: 16:41
 */

namespace app\models;
use yii\db\ActiveRecord;

class Bus extends ActiveRecord
{


}