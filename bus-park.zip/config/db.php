<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=bus_park',
    'username' => 'root',
    'password' => 'jimbdb',
    'charset' => 'utf8',
];
