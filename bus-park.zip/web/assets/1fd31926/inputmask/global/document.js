/*!
* global/document.js
* https://github.com/RobinHerbots/Inputmask
* Copyright (c) 2010 - 2017 Robin Herbots
* Licensed under the MIT license (http://www.opensource.org/licenses/mit-license.php)
* Version: 3.3.7
*/

"function" == typeof define && define.amd ? define(function() {
    return document;
}) : "object" == typeof exports && (module.exports = document);